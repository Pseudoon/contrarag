"""
ContraRAG — NLI Contradiction Detection Module
Drop this file into your project folder.
It is imported by app.py.
"""
from transformers import pipeline
import itertools

# Load once — this downloads ~90MB model first time
print("Loading NLI model...")
nli = pipeline(
    "text-classification",
    model="cross-encoder/nli-deberta-v3-small",
    device=-1  # CPU
)

def check_contradiction(texts):
    """
    Compare all pairs of retrieved chunks using NLI.
    Returns:
        contradiction_score: float 0.0-1.0 (higher = more contradiction)
        max_pair: the most contradicting pair of texts
        details: list of all pair scores
    """
    if len(texts) < 2:
        return 0.0, None, []

    pairs = list(itertools.combinations(texts[:6], 2))  # max 15 pairs
    details = []
    max_score = 0.0
    max_pair = None

    for t1, t2 in pairs:
        # NLI checks if t1 entails, is neutral, or contradicts t2
        inp = f"{t1[:400]} [SEP] {t2[:400]}"
        try:
            result = nli(inp, truncation=True, max_length=512)[0]
            label = result["label"].lower()
            score = result["score"]

            # Only count contradiction label
            contra_score = score if "contradict" in label else 0.0

            details.append({
                "text1": t1[:100] + "...",
                "text2": t2[:100] + "...",
                "label": label,
                "score": score,
                "contradiction_score": contra_score
            })

            if contra_score > max_score:
                max_score = contra_score
                max_pair = (t1, t2)

        except Exception as e:
            print(f"NLI error: {e}")
            continue

    return max_score, max_pair, details