"""
ContraRAG — FastAPI Backend
Run: uvicorn main:app --reload --port 8000
"""

import os, json
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv
from groq import Groq
from qdrant_client import QdrantClient
from qdrant_client.models import Filter, FieldCondition, MatchValue
from sentence_transformers import CrossEncoder, SentenceTransformer
from nli_contradiction import check_contradiction

load_dotenv()

app = FastAPI(title="ContraRAG API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

print("Loading models...")
embed_model = SentenceTransformer("all-MiniLM-L6-v2")
reranker = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")
qdrant = QdrantClient(url=os.getenv("QDRANT_URL"), api_key=os.getenv("QDRANT_API_KEY"), timeout=30)
client_eu = Groq(api_key=os.getenv("GROQ_API_KEY_EU"))
client_us = Groq(api_key=os.getenv("GROQ_API_KEY_US"))
client_judge = Groq(api_key=os.getenv("GROQ_API_KEY_JUDGE"))
print("All models loaded")

MODEL = "qwen/qwen3.6-27b"

class QueryRequest(BaseModel):
    question: str
    jurisdictions: list[str] = ["EU", "US", "UK"]

class ChatRequest(BaseModel):
    message: str
    context: str
    history: list[dict] = []


import re

def strip_think(text):
    """Remove <think>...</think> blocks from Qwen model output."""
    text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL)
    return text.strip()


def decompose_query(query):
    prompt = f"""Analyze this question: "{query}"
If SIMPLE (one jurisdiction, one concept): {{"is_complex": false, "sub_questions": ["{query}"]}}
If COMPLEX (comparison, multiple jurisdictions, multiple concepts): {{"is_complex": true, "sub_questions": ["sub-q 1", "sub-q 2"]}}
Return ONLY valid JSON, no extra text."""
    try:
        resp = client_judge.chat.completions.create(
            messages=[{"role": "user", "content": prompt}],
            model=MODEL, temperature=0.1
        ).choices[0].message.content
        start = resp.find('{')
        end = resp.rfind('}') + 1
        r = json.loads(resp[start:end])
        return r.get("sub_questions", [query]), r.get("is_complex", False)
    except:
        return [query], False


def search_qdrant(query, jurisdictions, sub_questions):
    all_raw = []
    for sub_q in sub_questions:
        vector = embed_model.encode(sub_q).tolist()
        for region in jurisdictions:
            results = qdrant.query_points(
                collection_name="ai_regulations",
                query=vector,
                limit=3,
                query_filter=Filter(must=[FieldCondition(key="jurisdiction", match=MatchValue(value=region))])
            ).points
            for r in results:
                all_raw.append({
                    "text": r.payload["text"],
                    "source": r.payload.get("source_file", "unknown"),
                    "jurisdiction": r.payload.get("jurisdiction", "unknown"),
                    "score": r.score,
                    "sub_query": sub_q
                })

    seen, unique = set(), []
    for r in all_raw:
        key = r["text"][:100]
        if key not in seen:
            seen.add(key)
            unique.append(r)

    if not unique:
        return "", []

    scores = reranker.predict([[query, c["text"]] for c in unique])
    for i, c in enumerate(unique):
        c["rerank_score"] = float(scores[i])
    unique.sort(key=lambda x: x["rerank_score"], reverse=True)
    top = unique[:5]

    context = "\n\n---\n\n".join(
        [f"[{c['jurisdiction']}] {c['source']}\n{c['text'][:600]}" for c in top]
    )
    return context, top


def run_agents(query, context):
    eu_prompt = f"""You are an EU AI regulation expert. Answer based ONLY on the context below in 3-4 sentences. Focus on EU-specific requirements.

Context:
{context}

Question: {query}"""

    eu_resp = strip_think(client_eu.chat.completions.create(
        messages=[{"role": "user", "content": eu_prompt}],
        model=MODEL, temperature=0.3
    ).choices[0].message.content)

    us_prompt = f"""You are a US and UK AI regulation expert. Answer based ONLY on the context below in 3-4 sentences. Highlight differences from the EU perspective.

Context:
{context}

Question: {query}"""

    us_resp = strip_think(client_us.chat.completions.create(
        messages=[{"role": "user", "content": us_prompt}],
        model=MODEL, temperature=0.3
    ).choices[0].message.content)

    return eu_resp, us_resp


def run_judge(query, context, eu_resp, us_resp, nli_score, nli_decision, nli_contradiction_found):
    judge_prompt = f"""You are ContraRAG's arbitrator. The NLI model has already determined:
- Contradiction score: {nli_score:.2f} (0=no contradiction, 1=strong contradiction)
- Contradiction found: {nli_contradiction_found}
- Decision: {nli_decision}

Based on the agent responses below, output ONLY valid JSON with no extra text:
{{
  "regional_summaries": {{
    "EU": "2-3 sentence summary of EU position",
    "US": "2-3 sentence summary of US position",
    "UK": "2-3 sentence summary of UK position"
  }},
  "contradiction_explanation": "Specific explanation of what contradicts, or No contradiction found",
  "decision_reason": "Why this decision was made"
}}

EU Agent: {eu_resp[:600]}
US Agent: {us_resp[:600]}"""

    raw = strip_think(client_judge.chat.completions.create(
        messages=[{"role": "user", "content": judge_prompt}],
        model=MODEL, temperature=0.1
    ).choices[0].message.content)
    # Extract JSON - handle markdown code blocks and raw JSON
    try:
        cleaned = re.sub(r'```(?:json)?', '', raw).strip()
        start = cleaned.find('{')
        end = cleaned.rfind('}') + 1
        return json.loads(cleaned[start:end])
    except:
        return {
            "regional_summaries": {
                "EU": eu_resp[:300],
                "US": us_resp[:300],
                "UK": "Not covered in retrieved documents"
            },
            "contradiction_explanation": "Could not parse judge response",
            "decision_reason": nli_decision
        }


@app.get("/health")
def health():
    return {"status": "ok", "chunks": 3982, "model": MODEL}


@app.post("/query")
def query(req: QueryRequest):
    if not req.question.strip():
        raise HTTPException(400, "Empty question")

    sub_questions, is_complex = decompose_query(req.question)
    context, trail = search_qdrant(req.question, req.jurisdictions, sub_questions)

    if not context:
        raise HTTPException(404, "No relevant documents found")

    eu_resp, us_resp = run_agents(req.question, context)

    chunk_texts = [c["text"] for c in trail]
    nli_score, nli_max_pair, nli_details = check_contradiction(chunk_texts)
    nli_contradiction_found = nli_score > 0.5
    nli_confidence = round(1.0 - nli_score, 2)

    if nli_confidence > 0.75:
        nli_decision = "ANSWER"
    elif nli_confidence > 0.4:
        nli_decision = "WARN"
    else:
        nli_decision = "REFUSE"

    judge_data = run_judge(req.question, context, eu_resp, us_resp,
                           nli_score, nli_decision, nli_contradiction_found)

    return {
        "sub_questions": sub_questions,
        "is_complex": is_complex,
        "eu_response": eu_resp,
        "us_response": us_resp,
        "sources": trail,
        "contradiction": {
            "found": nli_contradiction_found,
            "nli_score": nli_score,
            "explanation": judge_data.get("contradiction_explanation", ""),
            "max_pair": nli_max_pair
        },
        "verdict": {
            "decision": nli_decision,
            "confidence": nli_confidence,
            "friction_score": round(nli_score * 10),
            "decision_reason": judge_data.get("decision_reason", ""),
            "regional_summaries": judge_data.get("regional_summaries", {}),
        },
        "context": context
    }


@app.post("/chat")
def chat(req: ChatRequest):
    msgs = [{"role": "system", "content": f"Answer using only this context:\n{req.context[:3000]}"}]
    for m in req.history[-6:]:
        msgs.append({"role": m["role"], "content": m["content"]})
    msgs.append({"role": "user", "content": req.message})

    resp = client_judge.chat.completions.create(
        messages=msgs, model=MODEL, temperature=0.2
    ).choices[0].message.content

    return {"response": resp}